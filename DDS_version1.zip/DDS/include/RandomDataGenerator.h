#ifndef _RDG_H_

#define _RDG_H_

#include<iostream>
#include<string>
#include<random>

class RandomDataGenerator
{
public:
    float motor_speed();
    long motor_rpm();
    

    virtual ~RandomDataGenerator() {}
};

#endif