#include <../include/RandomDataGenerator.h>
#include <random>

float RandomDataGenerator::motor_speed() 
{ 
  int value=1+((rand()%200)+5-1);
  return value;
}

long RandomDataGenerator::motor_rpm()
{ 
  int value=1+((rand()%3000)+500-1);
  return value;
}


